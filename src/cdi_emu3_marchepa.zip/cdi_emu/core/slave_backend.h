#ifndef SLAVE_BACKEND_H
#define SLAVE_BACKEND_H
#include <stdint.h>

/* Interface que TOUT backend SLAVE doit implémenter.
   HLE et LLE respecteront ce contrat → interchangeables. */
typedef struct slave_backend {
    const char *name;              /* "HLE" ou "LLE-68HC05"          */
    void   *ctx;                   /* état interne du backend         */

    void    (*reset)(void *ctx);
    uint8_t (*read8) (void *ctx, uint32_t addr);
    void    (*write8)(void *ctx, uint32_t addr, uint8_t val);

    /* avance le SLAVE de N cycles maître (utile surtout en LLE).
       Retourne 1 si une IRQ vers le M68k est demandée.          */
    int     (*tick)(void *ctx, int master_cycles);

    /* injecte une entrée externe (pointeur, boutons) */
    void    (*push_input)(void *ctx, const uint8_t *report, int len);

    void    (*destroy)(void *ctx);
} slave_backend_t;

#endif

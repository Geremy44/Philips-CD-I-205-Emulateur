#include "m68k.h"
#include "m68k_ops.h"
#include "m68k_ea.h"
#include <string.h>
#include <stdio.h>

void m68k_init(m68k_t *cpu) {
    memset(cpu, 0, sizeof(*cpu));
}

void m68k_set_bus(m68k_t *cpu, bus_t *bus) {
    cpu->bus = bus;
}

void m68k_reset(m68k_t *cpu) {
    bus_t *saved = cpu->bus;
    memset(cpu, 0, sizeof(*cpu));
    cpu->bus = saved;
    cpu->stopped = 0;
    /* Load reset vector 0x00000E */
    cpu->sr |= 0x2000;  /* supervisor mode */
    cpu->pc  = m68k_read32(cpu, 0x000000);
    cpu->a[7] = m68k_read32(cpu, 0x000000);
}

/* Bus accessors forwarded to bus layer */

uint8_t m68k_read8(m68k_t *cpu, uint32_t addr) {
    return bus_read8(cpu->bus, addr);
}

uint16_t m68k_read16(m68k_t *cpu, uint32_t addr) {
    return bus_read16(cpu->bus, addr);
}

uint32_t m68k_read32(m68k_t *cpu, uint32_t addr) {
    uint32_t hi = bus_read16(cpu->bus, addr);
    uint32_t lo = bus_read16(cpu->bus, addr + 2);
    return (hi << 16) | lo;
}

/* Push / pop helpers (uses A7 as stack pointer) */

static inline void m68k_push16(m68k_t *cpu, uint16_t val) {
    cpu->a[7] -= 2;
    bus_write16(cpu->bus, cpu->a[7], val);
}

static inline uint16_t m68k_pop16(m68k_t *cpu) {
    uint16_t val = bus_read16(cpu->bus, cpu->a[7]);
    cpu->a[7] += 2;
    return val;
}

static inline void m68k_push32(m68k_t *cpu, uint32_t val) {
    cpu->a[7] -= 4;
    bus_write32(cpu->bus, cpu->a[7], val);
}

static inline uint32_t m68k_pop32(m68k_t *cpu) {
    uint32_t val = bus_read32(cpu->bus, cpu->a[7]);
    cpu->a[7] += 4;
    return val;
}

/* ===== Exception handling ===== */
__attribute__((unused))
static void m68k_exception(m68k_t *cpu, int vector, uint32_t pc) {
    /* Save PC and SR on stack */
    m68k_push32(cpu, pc);
    m68k_push16(cpu, cpu->sr);

    /* Load vector from 0xVECTOR (each vector is 4 bytes) */
    uint32_t vec_addr = (uint32_t)vector * 4;
    uint32_t vec = bus_read32(cpu->bus, vec_addr);
    cpu->pc = vec;
}

/* ===== Main step ===== */

int m68k_step(m68k_t *cpu) {
    if (cpu->stopped || cpu->halted) return 0;

    /* Decode and execute one instruction */
    m68k_step_ops(cpu);

    /* Rough cycle estimate per instruction (varies by opcode, approx 4-40) */
    return 4;
}

#include "bus.h"
#include "rom_loader.h"
#include "slave.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "scc66470.h"

#ifdef _WIN32
    #include <conio.h>
#endif

#define IO_BASE  0x80000000
#define IO_SIZE  0x00080000

#define UART_BASE  0x80002010
#define UART_SIZE  0x10

/* ===== Shared SCC66470 video state (non-static so main.c can tick it) ===== */
scc66470_t g_video;

/* ===== Global bus pointer (for uart_init etc.) ===== */
static bus_t *g_bus = NULL;

bus_t *bus_get_global(void) { return g_bus; }

static uint8_t uart_read8(bus_t *b, uint32_t addr);

static uint8_t io_regs[IO_SIZE];

/* ===== UART register offsets ===== */
#define UART_UMR  0x11   /* Mode Register       (R/W) */
#define UART_USR  0x13   /* Status Register     (RO) */
#define UART_UCS  0x15   /* Clock Select        (R/W) */
#define UART_UCR  0x17   /* Command Register    (WO) */
#define UART_UTH  0x19   /* Transmit Holding    (WO) */
#define UART_URX  0x1B   /* Receive Holding     (RO) */


/* ===== Address helpers ===== */

static inline int is_dram(uint32_t a)  { return a < 0x100000; }
static inline int is_nvram(uint32_t a) { return a >= 0x3F8000 && a < 0x3FC000; }
static inline int is_rom(uint32_t a)   { return a >= 0x180000 && a < 0x200000; }

static inline uint32_t nv_off(uint32_t a) { return a - 0x3F8000; }
static inline uint32_t rom_off(uint32_t a){ return a - 0x180000; }


/* ===== Bus create / destroy ===== */

bus_t *bus_create(void) {
    bus_t *b = calloc(1, sizeof(bus_t));
    if (!b) return NULL;
    /* pre-fill ROM with 0xFF (virgin EPROM state) */
    memset(b->rom,   0xFF, sizeof(b->rom));
    memset(b->dram,  0x00, sizeof(b->dram));
    memset(b->nvram, 0x00, sizeof(b->nvram));
    b->trace = 1;
    g_bus = b;
    uart_init(b);
    scc66470_init(&g_video);
    b->slave = slave_hle_create();
    b->slave->reset(b->slave->ctx);
    return b;
}

void bus_destroy(bus_t *b) {
    g_bus = NULL;
    free(b);
}

int bus_load_ihex(bus_t *b, const char *path) {
    size_t size = 0;
    uint8_t *rom_data = load_rom_hex(path, &size);

    if (!rom_data) {
        fprintf(stderr, "Failed to load ROM\n");
        return -1;
    }

    if (size > sizeof(b->rom)) {
        fprintf(stderr, "ROM file too large: %zu > %zu\n",
                size, sizeof(b->rom));
        free(rom_data);
        return -1;
    }

    memcpy(b->rom, rom_data, size);
    free(rom_data);
    return 0;
}


/* ===== UART init / feed ===== */

void uart_init(bus_t *b) {
    b->uart.rx_buf   = 0x00;
    b->uart.rx_ready = 0;
    b->uart.tx_buf   = 0x00;
    b->uart.mode     = 0x00;
    b->uart.cmd      = 0x00;
    b->uart.clksel   = 0x00;
}

void uart_feed(uint8_t byte) {
    bus_t *b = bus_get_global();
    if (!b) return;
    if (!b->uart.rx_ready) {
        b->uart.rx_buf   = byte;
        b->uart.rx_ready = 1;
    }
}

/* - Windows : _kbhit() / _getch() */
void uart_poll_host_input(void) {
    bus_t *b = bus_get_global();
    if (!b) return;
    if (b->uart.rx_ready) return;

#ifdef _WIN32
    if (_kbhit()) {
        int c = _getch();
        if (c != EOF) {
            if (c == '\r') c = '\n';
            uart_feed((uint8_t)c);
        }
    }
#else
    {
        fd_set rfds; struct timeval tv = {0,0};
        FD_ZERO(&rfds); FD_SET(STDIN_FILENO, &rfds);
        if (select(1, &rfds, NULL, NULL, &tv) > 0) {
            unsigned char c;
            if (read(STDIN_FILENO, &c, 1) == 1) {
                if (c == '\r') c = '\n';
                uart_feed(c);
            }
        }
    }
#endif
}


/* ===== I/O stubs ===== */

static uint16_t io_read_stub(uint32_t addr) {
    (void)addr;
    return 0xFFFF;
}

static void io_write_stub(uint32_t addr, uint16_t v) {
    (void)v;
    (void)addr;
}


/* ===== Bus read / write 8 / 16 / 32 ===== */

uint8_t bus_read8(bus_t *b, uint32_t addr) {

    if (addr >= 0x1FFFC0 && addr <= 0x1FFFFF) {
        return scc66470_read8(&g_video, addr);
    }

    if (addr >= 0x200000 && addr <= 0x207FFF) {
        return b->slave->read8(b->slave->ctx, addr);
    }

    /* ===== UART : 0x80002010–0x8000201F ===== */
    if (addr >= UART_BASE && addr < UART_BASE + UART_SIZE) {
        return uart_read8(b, addr);
    }

    if (addr >= IO_BASE && addr < IO_BASE + IO_SIZE) {
        return io_regs[addr - IO_BASE];
    }

    if (is_dram(addr))  return b->dram[addr];
    if (is_nvram(addr)) return b->nvram[nv_off(addr)];
    if (is_rom(addr))   return b->rom[rom_off(addr)];

    return io_read_stub(addr) & 0xFF;
}

uint16_t bus_read16(bus_t *b, uint32_t addr) {
    if (addr >= 0x1FFFC0 && addr <= 0x1FFFFF) {
        return scc66470_read16(&g_video, addr);
    }

    if (is_dram(addr)) {
        uint32_t o = addr;
        return ((uint16_t)b->dram[o] << 8) | b->dram[o + 1];
    }
    if (is_nvram(addr)) {
        uint32_t o = nv_off(addr);
        return ((uint16_t)b->nvram[o] << 8) | b->nvram[o + 1];
    }
    if (is_rom(addr)) {
        uint32_t o = rom_off(addr);
        return ((uint16_t)b->rom[o] << 8) | b->rom[o + 1];
    }

    return io_read_stub(addr);
}

uint32_t bus_read32(bus_t *b, uint32_t addr) {
    return ((uint32_t)bus_read16(b, addr) << 16) | bus_read16(b, addr + 2);
}

void bus_write8(bus_t *b, uint32_t addr, uint8_t v) {

    if (addr >= 0x1FFFC0 && addr <= 0x1FFFFF) {
        scc66470_write8(&g_video, addr, v);
        return;
    }

    /* ===== SLAVE 68HC05 ===== */
    if (addr >= 0x200000 && addr <= 0x207FFF) {
        b->slave->write8(b->slave->ctx, addr, v);
        return;
    }

    if (addr >= IO_BASE && addr < IO_BASE + IO_SIZE) {
        io_regs[addr - IO_BASE] = v;
        return;
    }

    if (is_dram(addr)) { b->dram[addr] = v; return; }
    if (is_rom(addr)) return;

    io_write_stub(addr, v);
}


void bus_write16(bus_t *b, uint32_t addr, uint16_t v) {

    if (addr >= 0x1FFFC0 && addr <= 0x1FFFFF) {
        scc66470_write16(&g_video, addr, v);
        return;
    }

    if (is_dram(addr)) {
        uint32_t o = addr;
        b->dram[o]     = (uint8_t)(v >> 8);
        b->dram[o + 1] = (uint8_t)(v & 0xFF);
        return;
    }
    if (is_nvram(addr)) {
        uint32_t o = nv_off(addr);
        b->nvram[o]     = (uint8_t)(v >> 8);
        b->nvram[o + 1] = (uint8_t)(v & 0xFF);
        return;
    }

    io_write_stub(addr, v);
}

void bus_write32(bus_t *b, uint32_t addr, uint32_t v) {
    bus_write16(b, addr,     (uint16_t)(v >> 16));
    bus_write16(b, addr + 2, (uint16_t)(v & 0xFFFF));
}


/* ===== UART inject ===== */

void uart_inject_rx(bus_t *b, uint8_t c) {
    b->uart.rx_buf   = c;
    b->uart.rx_ready = 1;
}


/* ===== UART read handler (8-bit only, base 0x80002010) ===== */

static uint8_t uart_read8(bus_t *b, uint32_t addr) {
    uint32_t off = addr & 0xFF;
    switch (off) {

    case UART_UMR:   /* 0x11 — Mode Register (lecture) */
        return b->uart.mode;

    case UART_USR: { /* 0x13 — Status Register (RO) */
        uint8_t usr = 0x04;              /* bit2 TxRDY = toujours prêt */
        if (b->uart.rx_ready) usr |= 0x01; /* bit0 RxRDY */
        return usr;
    }

    case UART_UCS:   /* 0x15 */
        return b->uart.clksel;

    case UART_UCR:   /* 0x17 */
        return b->uart.cmd;

    case UART_URX: { /* 0x1B — RX Holding (RO) */
        b->uart.rx_ready = 0;
        return b->uart.rx_buf;
    }

    case UART_UTH: { /* 0x19 — TX Holding (WO, lit en retour) */
        return b->uart.tx_buf;
    }

    default:
        return io_regs[off];
    }
}


/* ===== UART write handler (8-bit only) ===== */

void uart_write8(bus_t *b, uint32_t addr, uint8_t v) {
    uint32_t off = addr & 0xFF;

    switch (off) {

    case UART_UTH:   /* 0x19 — Transmit Holding (WO) */
        b->uart.tx_buf = v;
        putchar((char)v);
        fflush(stdout);
        return;

    case UART_UCR:   /* 0x17 */
        b->uart.cmd = v;
        break;

    case UART_UMR:   /* 0x11 */
        b->uart.mode = v;
        break;

    case UART_UCS:   /* 0x15 */
        b->uart.clksel = v;
        break;
    }

    io_regs[off] = v;
}

/* m68k_ea.c — Effective Address calculation and access */
#include "m68k_ea.h"
#include "m68k_ops.h"
#include <stdio.h>


uint32_t ea_read (m68k_t *cpu, uint8_t mode, uint8_t reg, int size) {
    uint32_t raw = ea_calc(cpu, mode, reg, size);
    if (size == 8)  return m68k_read8 (cpu, raw);
    if (size == 16) return m68k_read16(cpu, raw);
    return m68k_read32(cpu, raw);
}

void     ea_write(m68k_t *cpu, uint8_t mode, uint8_t reg, int size, uint32_t val) {
    uint32_t raw = ea_calc(cpu, mode, reg, size);
    if (size == 8) {
        bus_write8(cpu->bus, raw, (uint8_t)val);
    } else if (size == 16) {
        bus_write16(cpu->bus, raw, (uint16_t)val);
    } else {
        bus_write32(cpu->bus, raw, val);
    }
}


/* ===== ea_calc — decode addressing mode ===== */
uint32_t ea_calc (m68k_t *cpu, uint8_t mode, uint8_t reg, int size) {
    int inc = (size == 8) ? 1 : (size == 16) ? 2 : 4;

    switch (mode) {
        case 0: /* Dn */
            return 0xF0000000u | (uint32_t)reg;

        case 1: /* An */
            return 0xE0000000u | (uint32_t)reg;

        case 2: /* (An) */
            return cpu->a[reg];

        case 3: /* (An)+ */
        {
            uint32_t addr = cpu->a[reg];
            cpu->a[reg] += inc;
            return addr;
        }

        case 4: /* -(An) */
        {
            if (reg == 7 && size == 8) inc = 2;
            cpu->a[reg] -= inc;
            return cpu->a[reg];
        }

        case 5: /* d16(An) */
        {
            int16_t disp = (int16_t)m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            return (uint32_t)((int32_t)cpu->a[reg] + disp);
        }

        case 6: /* d8(An, Xn) */
        {
            uint16_t ext = m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            int8_t  d8  = (int8_t)(ext & 0xFF);
            int     xn  = (ext >> 12) & 0xF;
            uint32_t xv = cpu->d[xn];
            if ((ext & 0x8000) == 0) xv = cpu->a[xn & 7];
            return cpu->a[reg] + (uint32_t)d8 + xv;
        }

        case 7:
            switch (reg) {
                case 0: { /* abs.W */
                    int16_t a = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    return (uint32_t)a;
                }
                case 1: { /* abs.L */
                    uint32_t a = m68k_read32(cpu, cpu->pc);
                    cpu->pc += 4;
                    return a;
                }
                case 2: { /* d16(PC) */
                    int16_t disp = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    return cpu->pc + (uint32_t)disp;
                }
                case 3: { /* d8(PC, Xn) */
                    uint16_t ext = m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    int8_t  d8  = (int8_t)(ext & 0xFF);
                    int     xn  = (ext >> 12) & 0xF;
                    uint32_t xv = cpu->d[xn];
                    if ((ext & 0x8000) == 0) xv = cpu->a[xn & 7];
                    return cpu->pc + (uint32_t)d8 + xv;
                }

                case 4: { /* immediat */
                    uint32_t a = cpu->pc;
                    cpu->pc += (size == 32) ? 4 : 2;
                    return a;
                }

                default:
                    fprintf(stderr,
                        "ea_calc: unsupported mode=7 reg=%d PC=0x%08X\n",
                        reg, cpu->pc);
                    return 0;
            }
            break;

        default:
            fprintf(stderr,
                "ea_calc: unsupported mode=%d reg=%d PC=0x%08X\n",
                mode, reg, cpu->pc);
            cpu->stopped = 1;
            return 0;
    }

    fprintf(stderr,
        "ea_calc: fell through mode=%d reg=%d PC=0x%08X\n",
        mode, reg, cpu->pc);
    cpu->stopped = 1;
    return 0;
}

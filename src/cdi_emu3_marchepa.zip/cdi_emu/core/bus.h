#ifndef BUS_H
#define BUS_H
#include <stdint.h>
#include "slave_backend.h"

/* ===== UART state (kept in bus_t) ===== */
typedef struct uart_s {
    uint8_t  rx_buf;       /* last RX byte received */
    uint8_t  rx_ready;     /* receive data available flag */
    uint8_t  tx_buf;       /* last TX byte */
    uint8_t  mode;         /* UMR register snapshot */
    uint8_t  cmd;          /* UCR register snapshot */
    uint8_t  clksel;       /* UCS register snapshot */
} uart_t;

typedef struct bus_s {
    uint8_t dram[0x100000];   /* 1 MB  @ 0x000000 */
    uint8_t rom [0x080000];   /* 512 KB @ 0x180000 */
    uint8_t nvram[0x004000];  /* 16 KB  @ 0x3F8000 */
    uart_t  uart;             /* UART peripheral state */
    int trace;
    slave_backend_t *slave;
} bus_t;

/* ===== Shared SCC66470 video instance (defined in bus.c) ===== */
struct scc66470_s;
typedef struct scc66470_s scc66470_t;
extern scc66470_t g_video;

bus_t *bus_create(void);
void   bus_destroy(bus_t *b);
int    bus_load_ihex(bus_t *b, const char *path);

bus_t *bus_get_global(void);

uint8_t  bus_read8 (bus_t *b, uint32_t addr);
uint16_t bus_read16(bus_t *b, uint32_t addr);
uint32_t bus_read32(bus_t *b, uint32_t addr);
void bus_write8 (bus_t *b, uint32_t addr, uint8_t  v);
void bus_write16(bus_t *b, uint32_t addr, uint16_t v);
void bus_write32(bus_t *b, uint32_t addr, uint32_t v);

/* ===== UART public API ===== */
void uart_init(bus_t *b);
void uart_feed(uint8_t byte);
void uart_poll_host_input(void);
void uart_inject_rx(bus_t *b, uint8_t c);

#endif

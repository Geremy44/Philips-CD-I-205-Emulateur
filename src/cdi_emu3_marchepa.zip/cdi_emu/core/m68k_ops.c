#include "m68k_ops.h"
#include "m68k_ea.h"
#include <stdio.h>

#ifndef SR_N
#define SR_N 0x0008
#define SR_Z 0x0004
#define SR_V 0x0002
#define SR_C 0x0001
#define SR_X 0x0010
#endif

static inline void set_nz_flags8(m68k_t *cpu, uint8_t val) {
    cpu->sr &= ~(SR_N | SR_Z);
    if (val == 0)        cpu->sr |= SR_Z;
    if (val & 0x80)      cpu->sr |= SR_N;
}

static inline void set_nz_flags16(m68k_t *cpu, uint16_t val) {
    cpu->sr &= ~(SR_N | SR_Z);
    if (val == 0)        cpu->sr |= SR_Z;
    if (val & 0x8000)    cpu->sr |= SR_N;
}

static inline void set_nz_flags32(m68k_t *cpu, uint32_t val) {
    cpu->sr &= ~(SR_N | SR_Z);
    if (val == 0)        cpu->sr |= SR_Z;
    if (val & 0x80000000)cpu->sr |= SR_N;
}


/* ----- Flag helpers ----- */
static void flag_NZ_clearVC(uint16_t *sr, uint32_t r, int size)
{
    *sr &= ~(SR_N | SR_Z | SR_V | SR_C);
    if (size == 8) {
        if ((uint8_t)r == 0)  *sr |= SR_Z;
        if (r & 0x80)         *sr |= SR_N;
    } else if (size == 16) {
        if ((uint16_t)r == 0) *sr |= SR_Z;
        if (r & 0x8000)       *sr |= SR_N;
    } else {
        if (r == 0)           *sr |= SR_Z;
        if (r & 0x80000000)   *sr |= SR_N;
    }
}

int cc_true(uint16_t sr, int cc) {
    int C = (sr >> 0) & 1;
    int V = (sr >> 1) & 1;
    int Z = (sr >> 2) & 1;
    int N = (sr >> 3) & 1;
    switch (cc) {
        case 0x0: return 1;              /* T  */
        case 0x1: return 0;              /* F  */
        case 0x2: return !C && !Z;       /* HI */
        case 0x3: return C || Z;         /* LS */
        case 0x4: return !C;             /* CC */
        case 0x5: return C;              /* CS */
        case 0x6: return !Z;             /* NE */
        case 0x7: return Z;              /* EQ ← ICI, doit renvoyer Z=1 → 1 */
        case 0x8: return !V;             /* VC */
        case 0x9: return V;              /* VS */
        case 0xA: return !N;             /* PL */
        case 0xB: return N;              /* MI */
        case 0xC: return (N==V);         /* GE */
        case 0xD: return (N!=V);         /* LT */
        case 0xE: return !Z && (N==V);   /* GT */
        case 0xF: return Z || (N!=V);    /* LE */
    }
    return 0;
}


static void push32(m68k_t *cpu, uint32_t val)
{
    cpu->a[7] -= 4;
    bus_write32(cpu->bus, cpu->a[7], val);
}

void flag_sub(uint16_t *sr, uint32_t d, uint32_t s, uint32_t r, int size) {
    uint32_t msb = (size == 8) ? 0x80 : (size == 16) ? 0x8000 : 0x80000000u;
    uint32_t mask = (size == 8) ? 0xFF : (size == 16) ? 0xFFFF : 0xFFFFFFFFu;
    r &= mask; d &= mask; s &= mask;

    *sr &= ~0x0F;                                  /* clear C,V,Z,N */
    if (r == 0)            *sr |= 0x04;            /* Z */
    if (r & msb)           *sr |= 0x08;            /* N */
    if (((s ^ d) & (d ^ r)) & msb) *sr |= 0x02;    /* V */
    if (s > d)             *sr |= 0x01;            /* C (borrow) */
    /* CMP n'affecte pas X */
}

static inline uint32_t mask_of(int size) {
    return (size == 8) ? 0xFFu :
           (size == 16) ? 0xFFFFu : 0xFFFFFFFFu;
}

/* ================================================================
 * 68000 Address Error (vecteur 3) — frame 18 octets (0x12)
 * ================================================================ */
void m68k_address_error(m68k_t *cpu, uint32_t fault_addr, uint32_t ir)
{
    uint16_t old_sr = cpu->sr;
    uint32_t old_pc = cpu->pc;

    cpu->sr |=  0x2000;   /* superviseur */
    cpu->sr &= ~0x8000;   /* clear trace */

    /* Frame court 68000 = 7 mots = 14 octets (PAS de vector offset !) */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], old_pc & 0xFFFF);     /* PC low  */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], old_pc >> 16);        /* PC high */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], old_sr);              /* SR      */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], ir & 0xFFFF);         /* IR      */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], fault_addr & 0xFFFF); /* fault low  */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], fault_addr >> 16);    /* fault high */
    cpu->a[7] -= 2; bus_write16(cpu->bus, cpu->a[7], 0x0009);              /* SSW     */

    /* handler = vecteur 3 (table à 0x180000, offset 0x0C) */
    cpu->pc = ((uint32_t)m68k_read16(cpu, 0x18000C) << 16)
            |  (uint32_t)m68k_read16(cpu, 0x18000E);
}

/* ================================================================
 * Décodeur principal
 * ================================================================ */
void m68k_step_ops(m68k_t *cpu)
{
    if (cpu->pc & 1) {
        m68k_address_error(cpu, cpu->pc, 0x0000);
        return;
    }

    uint16_t insn = m68k_read16(cpu, cpu->pc);
    cpu->pc += 2;

    uint8_t  nib0    = (uint8_t)(insn >> 12);
    uint8_t  nib1    = (uint8_t)((insn >> 6) & 0x3F);
    uint8_t  ea_mode = (uint8_t)((insn >> 3) & 0x07);
    uint8_t  ea_reg  = (uint8_t)(insn & 0x07);
    uint32_t base    = cpu->pc;   /* base des branches relatives */
    int cc = (insn >> 8) & 0xF;

    switch (nib0) {

    /* ---------- 0x0 : ORI/ANDI/EORI CCR-SR + Bit ops ---------- */
    case 0x0: {
        if (insn == 0x003C) {                       /* ORI #imm,CCR */
            uint16_t imm = m68k_read16(cpu, cpu->pc); cpu->pc += 2;
            cpu->sr = (cpu->sr & ~0x001F) | ((cpu->sr | imm) & 0x001F);
            return;
        }
        if (insn == 0x007C) {                       /* ORI #imm,SR */
            uint16_t imm = m68k_read16(cpu, cpu->pc); cpu->pc += 2;
            cpu->sr |= imm; return;
        }
        if (insn == 0x027C) {                       /* ANDI #imm,SR */
            uint16_t imm = m68k_read16(cpu, cpu->pc); cpu->pc += 2;
            cpu->sr &= imm; return;
        }
        if (insn == 0x0A7C) {                       /* EORI #imm,SR */
            uint16_t imm = m68k_read16(cpu, cpu->pc); cpu->pc += 2;
            cpu->sr ^= imm; return;
        }
        if ((insn & 0xFF00) == 0x0800) {            /* BTST/BCHG/BCLR/BSET #imm */
            uint16_t bitsel = m68k_read16(cpu, cpu->pc); cpu->pc += 2;
            int size = (ea_mode == 0) ? 32 : 8;

            // fprintf(stderr, "[BTST] ea_mode=%d ea_reg=%d bitsel=%u pc=%06X\n",
            // ea_mode, ea_reg, bitsel, cpu->pc);

            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);

            // fprintf(stderr, "[BTST] val lu=%08X bit=%d -> Z=%d\n",
            // val, bitsel & 7, !(val & (1u<<(bitsel&7))));

            int op = (insn >> 6) & 3;
            int bit = bitsel & ((size == 32) ? 31 : 7);
            uint32_t mask = 1u << bit;
            cpu->sr &= ~SR_Z;

            //fprintf(stderr, "[BTST] addr=%06X val=%08X bit=%d\n", ea_addr, val, bit);


            if (!(val & mask)) cpu->sr |= SR_Z;
            if (op == 1) val ^= mask;
            else if (op == 2) val &= ~mask;
            else if (op == 3) val |= mask;
            if (op != 0) ea_write(cpu, ea_mode, ea_reg, size, val);
            return;
        }
        return;
    }

    /* ---------- MOVE.B / MOVE.L / MOVE.W ---------- */
    case 0x1: case 0x2: case 0x3: {
        int size = (nib0 == 0x1) ? 8 : (nib0 == 0x2) ? 32 : 16;
        uint8_t src_mode = ea_mode, src_reg = ea_reg;
        uint8_t dst_reg  = (insn >> 9) & 7;
        uint8_t dst_mode = (insn >> 6) & 7;

        uint32_t val = ea_read(cpu, src_mode, src_reg, size);

        if (dst_mode == 1) {                        /* MOVEA */
            if (size == 16) val = (uint32_t)(int32_t)(int16_t)val;
            cpu->a[dst_reg] = val;
        } else {
            ea_write(cpu, dst_mode, dst_reg, size, val);
            flag_NZ_clearVC(&cpu->sr, val, size);
        }
        return;
    }

        /* ---------- 0x4 : divers (JMP/JSR/RTS/LEA/NOP/MOVE USP...) ---------- */
    case 0x4: {
        if (insn == 0x4E75) {                       /* RTS */
            uint32_t via_bus = bus_read32(cpu->bus, cpu->a[7]);
            uint32_t via_cpu = m68k_read32(cpu, cpu->a[7]);
            fprintf(stderr, "[RTS] A7=%08X  bus_read32=%08X  m68k_read32=%08X\n",
                    cpu->a[7], via_bus, via_cpu);
            cpu->pc = via_cpu;
            cpu->a[7] += 4;
            return;
        }
        if (insn == 0x4E71) {                       /* NOP */
            return;
        }
        if (insn == 0x4E77) {                        /* RTR */
            uint16_t ccr = m68k_read16(cpu, cpu->a[7]); cpu->a[7] += 2;
            cpu->sr = (cpu->sr & 0xFF00) | (ccr & 0x00FF);
            cpu->pc = m68k_read32(cpu, cpu->a[7]); cpu->a[7] += 4;
            return;
        }
        if (insn == 0x4E73) {                        /* RTE */
            cpu->sr = m68k_read16(cpu, cpu->a[7]); cpu->a[7] += 2;
            cpu->pc = m68k_read32(cpu, cpu->a[7]); cpu->a[7] += 4;
            return;
        }
        if ((insn & 0xFFF8) == 0x4E60) {             /* MOVE An,USP */
            cpu->usp = cpu->a[insn & 7];
            return;
        }
        if ((insn & 0xFFF8) == 0x4E68) {             /* MOVE USP,An */
            cpu->a[insn & 7] = cpu->usp;
            return;
        }
        if ((insn & 0xFFC0) == 0x4EC0) {             /* JMP <ea> */
            uint32_t target = ea_calc(cpu, ea_mode, ea_reg, 32);
            if (target & 1) {
                m68k_address_error(cpu, target, insn);   /* fault = cible impaire */
                return;
            }
            cpu->pc = target;
            return;
        }
        if ((insn & 0xFFC0) == 0x4E80) {             /* JSR <ea> */
            uint32_t target = ea_calc(cpu, ea_mode, ea_reg, 32);
            push32(cpu, cpu->pc);
            cpu->pc = target;
            return;
        }
        if ((insn & 0xF1C0) == 0x41C0) {             /* LEA <ea>,An */
            uint8_t an = (insn >> 9) & 7;
            cpu->a[an] = ea_calc(cpu, ea_mode, ea_reg, 32);
            return;
        }
        if ((insn & 0xFF00) == 0x4200) {             /* CLR <ea> */
            int size = ((insn>>6)&3)==0 ? 8 : ((insn>>6)&3)==1 ? 16 : 32;
            ea_write(cpu, ea_mode, ea_reg, size, 0);
            cpu->sr = (cpu->sr & ~(SR_N|SR_V|SR_C)) | SR_Z;
            return;
        }
        if ((insn & 0xFF00) == 0x4A00) {             /* TST <ea> */
            int size = ((insn>>6)&3)==0 ? 8 : ((insn>>6)&3)==1 ? 16 : 32;
            uint32_t v = ea_read(cpu, ea_mode, ea_reg, size);
            flag_NZ_clearVC(&cpu->sr, v, size);
            return;
        }

                if ((insn & 0xFFF8) == 0x4840) {             /* SWAP Dn */
            uint8_t dn = insn & 7;
            uint32_t v = cpu->d[dn];
            cpu->d[dn] = (v >> 16) | (v << 16);
            flag_NZ_clearVC(&cpu->sr, cpu->d[dn], 32);
            return;
        }
        if ((insn & 0xFFC0) == 0x4840) {             /* PEA <ea> */
            uint32_t ea = ea_calc(cpu, ea_mode, ea_reg, 32);
            push32(cpu, ea);
            return;
        }

                if ((insn & 0xFB80) == 0x4880) {             /* MOVEM */
            uint16_t mask = m68k_read16(cpu, cpu->pc); cpu->pc += 2;
            int is_long  = (insn >> 6) & 1;          /* 1=long, 0=word */
            int to_mem   = !((insn >> 10) & 1);      /* bit10=0 → reg→mem */
            int sz       = is_long ? 4 : 2;

            if (to_mem) {
                /* registres → mémoire */
                if (ea_mode == 4) {
                    /* -(An) prédécrément : ordre inversé, bit0=A7 ... bit15=D0 */
                    uint32_t addr = cpu->a[ea_reg];
                    for (int i = 0; i < 16; i++) {
                        if (mask & (1 << i)) {
                            /* i=0→A7, i=7→A0, i=8→D7, i=15→D0 */
                            uint32_t val;
                            if (i < 8) val = cpu->a[7 - i];
                            else       val = cpu->d[15 - i];
                            addr -= sz;
                            if (is_long) bus_write32(cpu->bus, addr, val);
                            else         bus_write16(cpu->bus, addr, val & 0xFFFF);
                        }
                    }
                    cpu->a[ea_reg] = addr;
                } else {
                    /* autre mode (contrôle) : ordre normal, bit0=D0 ... bit15=A7 */
                    uint32_t addr = ea_calc(cpu, ea_mode, ea_reg, 32);
                    for (int i = 0; i < 16; i++) {
                        if (mask & (1 << i)) {
                            uint32_t val = (i < 8) ? cpu->d[i] : cpu->a[i - 8];
                            if (is_long) bus_write32(cpu->bus, addr, val);
                            else         bus_write16(cpu->bus, addr, val & 0xFFFF);
                            addr += sz;
                        }
                    }
                }
            } else {
                /* mémoire → registres : ordre normal bit0=D0 ... bit15=A7 */
                if (ea_mode == 3) {
                    /* (An)+ postincrément */
                    uint32_t addr = cpu->a[ea_reg];
                    for (int i = 0; i < 16; i++) {
                        if (mask & (1 << i)) {
                            uint32_t val = is_long ? m68k_read32(cpu, addr)
                                                   : (uint32_t)(int32_t)(int16_t)m68k_read16(cpu, addr);
                            if (i < 8) cpu->d[i]     = val;
                            else       cpu->a[i - 8] = val;
                            addr += sz;
                        }
                    }
                    cpu->a[ea_reg] = addr;
                } else {
                    uint32_t addr = ea_calc(cpu, ea_mode, ea_reg, 32);
                    for (int i = 0; i < 16; i++) {
                        if (mask & (1 << i)) {
                            uint32_t val = is_long ? m68k_read32(cpu, addr)
                                                   : (uint32_t)(int32_t)(int16_t)m68k_read16(cpu, addr);
                            if (i < 8) cpu->d[i]     = val;
                            else       cpu->a[i - 8] = val;
                            addr += sz;
                        }
                    }
                }
            }
            return;
        }



        fprintf(stderr, "[m68k] 0x4xxx non géré 0x%04X @PC=0x%08X\n",
                insn, base - 2);
        cpu->stopped = 1;
        return;
    }

    /* ---------- 0x5 : ADDQ / SUBQ / Scc / DBcc ---------- */
case 0x5: {
    uint8_t size_field = (insn >> 6) & 3;

    if (size_field == 3) {
        /* bits 7-6 = 11 → Scc ou DBcc */
        int cc = (insn >> 8) & 0xF;

        if (ea_mode == 1) {
            /* DBcc Dn, disp16 */
            uint32_t insn_pc   = cpu->pc - 2;          /* PC du DBcc lui-même */
            int16_t  disp      = (int16_t)m68k_read16(cpu, cpu->pc);
            uint32_t disp_base = cpu->pc;              /* PC après le mot de déplacement */
            cpu->pc += 2;

            uint32_t cible = disp_base + (uint32_t)(int32_t)disp;

            if (!cc_true(cpu->sr, cc)) {

                /* ===== COURT-CIRCUIT : boucle de délai vide (DBF Dn, self) ===== */
                if (cible == insn_pc) {
                    /* le corps de boucle est vide : la cible EST le DBcc.
                       On vide le compteur d'un coup → sortie immédiate.
                       Le mot bas de Dn passe à 0xFFFF (état de sortie). */
                    cpu->d[ea_reg] = (cpu->d[ea_reg] & 0xFFFF0000) | 0xFFFF;
                    /* pas de saut : on continue après le DBcc */
                    return;
                }
                /* ===== fin court-circuit ===== */

                /* condition fausse → décrémente le compteur (mot bas de Dn) */
                uint16_t counter = (uint16_t)(cpu->d[ea_reg] & 0xFFFF) - 1;
                cpu->d[ea_reg] = (cpu->d[ea_reg] & 0xFFFF0000) | counter;
                if (counter != 0xFFFF) {
                    /* pas -1 → on branche */
                    cpu->pc = cible;
                }
            }
            /* condition vraie OU compteur arrivé à -1 → on continue */
            return;

        } else {
            /* Scc <ea> : met l'octet à 0xFF si vrai, 0x00 sinon */
            uint8_t val = cc_true(cpu->sr, cc) ? 0xFF : 0x00;
            ea_write(cpu, ea_mode, ea_reg, 8, val);
            return;
        }
    } else {
        /* ADDQ / SUBQ #data, <ea> */
        int size = (size_field == 0) ? 8 : (size_field == 1) ? 16 : 32;
        uint8_t data = (insn >> 9) & 7;
        if (data == 0) data = 8;          /* 0 signifie 8 */
        int is_sub = (insn >> 8) & 1;     /* bit 8 : 0=ADDQ, 1=SUBQ */

        /* NB : ea_mode==1 (An) est valide pour ADDQ/SUBQ .W/.L
           et n'affecte PAS les flags. On le gère proprement. */
        if (ea_mode == 1) {
            /* ADDQ/SUBQ sur registre d'adresse : opère sur 32 bits, pas de flags */
            uint32_t val = cpu->a[ea_reg];
            cpu->a[ea_reg] = is_sub ? (val - data) : (val + data);
            return;
        }

        uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
        uint32_t res = is_sub ? (val - data) : (val + data);
        ea_write(cpu, ea_mode, ea_reg, size, res);
        flag_NZ_clearVC(&cpu->sr, res, size);
        return;
    }
}




    /* ---------- 0x6 : Bcc / BRA / BSR ---------- */
    case 0x6: {

        int8_t disp8 = (int8_t)(insn & 0xFF);
        int32_t disp;
        if (disp8 == 0) {
            disp = (int16_t)m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
        } else {
            disp = disp8;
        }
        
        if (cc == 1) {                              /* BSR */
            push32(cpu, cpu->pc);
            cpu->pc = base + (uint32_t)disp;
        } else if (cc_true(cpu->sr, cc)) {          /* Bcc / BRA */
            cpu->pc = base + (uint32_t)disp;
        }
        return;
    }

    /* ---------- 0x7 : MOVEQ ---------- */
    case 0x7:
        cpu->d[(insn >> 9) & 7] = (uint32_t)(int32_t)(int8_t)(insn & 0xFF);
        flag_NZ_clearVC(&cpu->sr, cpu->d[(insn >> 9) & 7], 32);
        return;

    /* ---------- 0x8 : OR ---------- */
    case 0x8: {
        int size = 16;
        uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
        uint8_t dn = (insn >> 9) & 7;
        cpu->d[dn] |= (val & 0xFFFF);
        flag_NZ_clearVC(&cpu->sr, cpu->d[dn], size);
        return;
    }

    /* ---------- 0x9 : SUB / SUBA ---------- */
    case 0x9: {
        int size = ((insn & 0x00C0) == 0x00C0) ? 32 : 16;
        uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
        uint8_t dn = (insn >> 9) & 7;
        if ((insn & 0x00C0) == 0x00C0 && ((insn>>8)&1)==0) { /* SUBA */
            cpu->a[dn] -= val;
        } else {
            uint32_t res = cpu->d[dn] - val;
            cpu->d[dn] = res;
            flag_NZ_clearVC(&cpu->sr, res, size);
        }
        return;
    }

   /* ---------- 0xB : CMP / CMPA / CMPM / EOR ---------- */
case 0xB: {
    uint8_t dn      = (insn >> 9) & 7;
    uint8_t opmode  = (insn >> 6) & 7;   /* bits 8-6 */

    printf("[0xB] insn=%04X opmode=%d\n", insn, opmode);  // ← DEBUG

    /* --- CMPA : opmode 011 (word) ou 111 (long) --- */
    if (opmode == 0x3 || opmode == 0x7) {
        int size = (opmode == 0x7) ? 32 : 16;
        uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
        if (size == 16) val = (uint32_t)(int32_t)(int16_t)val;  /* sign-extend */
        uint32_t res = cpu->a[dn] - val;
        flag_sub(&cpu->sr, cpu->a[dn], val, res, 32);
        return;
    }

    /* --- opmode 0/1/2 = CMP ; opmode 4/5/6 = EOR --- */
    int size = (opmode & 3) == 0 ? 8 : (opmode & 3) == 1 ? 16 : 32;

    printf("[0xB-body] opmode=%d size=%d ea_mode=%d ea_reg=%d\n",
       opmode, size, ea_mode, ea_reg);

    if (opmode & 0x4) {
        /* EOR Dn, <ea> */
        uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
        uint32_t res = val ^ (cpu->d[dn] & mask_of(size));
        ea_write(cpu, ea_mode, ea_reg, size, res);
        flag_NZ_clearVC(&cpu->sr, res, size);
    } else {
        /* CMP <ea>, Dn */
        uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
        uint32_t d   = cpu->d[dn];
        uint32_t res = d - val;
        printf("[CMP-pre]  d=%08X val=%08X res=%08X sr=%04X\n", d, val, res, cpu->sr);
        flag_sub(&cpu->sr, d, val, res, size);   /* ← calcule Z,N,V,C correctement */
        printf("[CMP-post] sr=%04X\n", cpu->sr);
    }
    return;
}


        /* ---------- 0xC : AND / MUL / ABCD / EXG ---------- */
    case 0xC: {
        int dn      = (insn >> 9) & 7;
        int opmode  = (insn >> 6) & 7;   // bits 6-7-8
        int mode    = ea_mode;           // (insn >> 3) & 7
        int reg     = ea_reg;            // insn & 7

        /* --- MULU : opmode=011 (1100 xxx 011 eeeeee) --- */
        if (opmode == 3) {
            uint16_t src = (uint16_t)ea_read(cpu, mode, reg, 16);  // .W
            uint32_t res = (uint32_t)(cpu->d[dn] & 0xFFFF) * src;
            cpu->d[dn] = res;
            set_nz_flags32(cpu, res);
            cpu->sr &= ~(SR_V | SR_C);
            return;
        }

        /* --- MULS : opmode=111 (1100 xxx 111 eeeeee) --- */
        if (opmode == 7) {
            int16_t src = (int16_t)ea_read(cpu, mode, reg, 16);   // .W signé
            int32_t res = (int32_t)(int16_t)(cpu->d[dn] & 0xFFFF) * src;
            cpu->d[dn] = (uint32_t)res;
            set_nz_flags32(cpu, (uint32_t)res);
            cpu->sr &= ~(SR_V | SR_C);
            return;
        }

        /* --- ABCD : 1100 xxx1 0000 r eee (bits 8=1, 7-4=0000) --- */
        if ((insn & 0x01F0) == 0x0100) {
            // ... ABCD (BCD add) — à implémenter si besoin
            fprintf(stderr, "[m68k] ABCD non implémenté @%06X\n", cpu->pc-2);
            return;
        }

        /* --- EXG : 1100 xxx1 modeexg reg (bit8=1) --- */
        if ((insn & 0x0100) && 
            (((insn >> 3) & 0x1F) == 0x08 ||   // EXG Dx,Dy (01000)
             ((insn >> 3) & 0x1F) == 0x09 ||   // EXG Ax,Ay (01001)
             ((insn >> 3) & 0x1F) == 0x11)) {  // EXG Dx,Ay (10001)
            int rx = dn;
            int ry = reg;
            uint8_t exmode = (insn >> 3) & 0x1F;
            uint32_t tmp;
            if (exmode == 0x08) {              // Dx <-> Dy
                tmp = cpu->d[rx]; cpu->d[rx] = cpu->d[ry]; cpu->d[ry] = tmp;
            } else if (exmode == 0x09) {       // Ax <-> Ay
                tmp = cpu->a[rx]; cpu->a[rx] = cpu->a[ry]; cpu->a[ry] = tmp;
            } else {                           // Dx <-> Ay
                tmp = cpu->d[rx]; cpu->d[rx] = cpu->a[ry]; cpu->a[ry] = tmp;
            }
            return;  // EXG n'affecte pas les flags
        }

         /* --- AND --- */
        {
            int size_code = opmode & 3;                     // 0/1/2
            int size = (size_code == 0) ? 8 
                    : (size_code == 1) ? 16 : 32;
            int dir  = (opmode >> 2) & 1;   // 0: Dn=Dn&ea, 1: ea=ea&Dn

            if (dir == 0) {
                /* Dn = Dn AND <ea> */
                uint32_t src = ea_read(cpu, mode, reg, size);
                uint32_t dst = cpu->d[dn];
                uint32_t res;
                switch (size) {
                    case 0: res = (dst & ~0xFFu)   | ((dst & src) & 0xFF);
                            set_nz_flags8 (cpu, res & 0xFF);   break;
                    case 1: res = (dst & ~0xFFFFu) | ((dst & src) & 0xFFFF);
                            set_nz_flags16(cpu, res & 0xFFFF); break;
                    default:res = dst & src;
                            set_nz_flags32(cpu, res);          break;
                }
                cpu->d[dn] = res;
            } else {
                /* <ea> = <ea> AND Dn  (⚠️ lit puis réécrit la MÊME ea) */
                uint32_t src    = ea_read(cpu, mode, reg, size);
                uint32_t dn_val = cpu->d[dn];
                uint32_t res;
                switch (size) {
                    case 0: res = (src & dn_val) & 0xFF;
                            set_nz_flags8 (cpu, res); break;
                    case 1: res = (src & dn_val) & 0xFFFF;
                            set_nz_flags16(cpu, res); break;
                    default:res = src & dn_val;
                            set_nz_flags32(cpu, res); break;
                }
                ea_write(cpu, mode, reg, size, res);
            }
            cpu->sr &= ~(SR_V | SR_C);   // V=C=0, X inchangé
            return;
        }
    } /* fin case 0xC */
    
    case 0xD: {   /* ADD / ADDA */
        int dn       = (insn >> 9) & 7;
        int opmode   = (insn >> 6) & 7;
        uint8_t mode = (insn >> 3) & 7;
        uint8_t reg  =  insn & 7;

        /* ---- ADDA : opmode 011 (.W) / 111 (.L) → dest = An ---- */
        if (opmode == 3 || opmode == 7) {
            int size = (opmode == 7) ? 32 : 16;
            uint32_t src = ea_read(cpu, mode, reg, size);
            if (size == 16) src = (uint32_t)(int32_t)(int16_t)src;
            cpu->a[dn] += src;
            break;
        }

        int size = (opmode & 3) == 0 ? 8 : (opmode & 3) == 1 ? 16 : 32;

        if (opmode & 4) {
            /* ---- sens <ea> = <ea> + Dn ----
            Pour éviter le double post-incrément sur (An)+ / -(An),
            on lit l'adresse une fois via ea_calc puis on lit/écrit
            en registre direct si mode Dn, sinon via ea sur adresse figée. */

            if (mode == 0) {
                /* destination = Dn (rare pour ce sens mais légal via mode 0) */
                uint32_t s   = cpu->d[reg];
                uint32_t res = s + cpu->d[dn];
                if      (size == 8)  cpu->d[reg] = (cpu->d[reg] & 0xFFFFFF00) | (res & 0xFF);
                else if (size == 16) cpu->d[reg] = (cpu->d[reg] & 0xFFFF0000) | (res & 0xFFFF);
                else                 cpu->d[reg] = res;
                flag_NZ_clearVC(&cpu->sr, res, size);
            } else {
                /* mode mémoire : ea_read fait le calcul+incrément UNE fois,
                puis on réécrit SANS re-incrémenter en repassant par mode
                indirect simple (An) via un ea_write "neutre".
                → on capture l'adresse d'abord. */
                uint32_t ea = ea_calc(cpu, mode, reg, size);  /* NOTE: si (An)+ ça incrémente déjà */
                uint32_t s;
                if      (size == 8)  s = m68k_read8 (cpu, ea);
                else if (size == 16) s = m68k_read16(cpu, ea);
                else                 s = m68k_read32(cpu, ea);

                uint32_t res = s + cpu->d[dn];

                /* écriture via TA fonction bus (à confirmer par le grep) */
                if      (size == 8)  bus_write8 (cpu->bus, ea, res & 0xFF);
                else if (size == 16) bus_write16(cpu->bus, ea, res & 0xFFFF);
                else                 bus_write32(cpu->bus, ea, res);

                flag_NZ_clearVC(&cpu->sr, res, size);
            }
        } else {
            /* ---- sens Dn = Dn + <ea> ---- */
            uint32_t s   = ea_read(cpu, mode, reg, size);
            uint32_t d   = cpu->d[dn];
            uint32_t res = d + s;
            if      (size == 8)  cpu->d[dn] = (d & 0xFFFFFF00) | (res & 0xFF);
            else if (size == 16) cpu->d[dn] = (d & 0xFFFF0000) | (res & 0xFFFF);
            else                 cpu->d[dn] = res;
            flag_NZ_clearVC(&cpu->sr, res, size);
        }
        break;
    }

    default:
        /* opcode non implémenté → on s'arrête proprement */
        fprintf(stderr, "[m68k] opcode non géré 0x%04X @PC=0x%08X\n",
                insn, base - 2);
        cpu->stopped = 1;
        return;
    }

    (void)nib1;  /* gardé pour usage futur */
}

#ifndef SCC66470_H
#define SCC66470_H

#include <stdint.h>

/* Le typedef peut déjà avoir été fait dans bus.h.
   On le protège pour éviter le "conflicting types". */
#ifndef SCC66470_T_DEFINED
#define SCC66470_T_DEFINED
typedef struct scc66470_s scc66470_t;
#endif

/* Contrôleur vidéo SCC66470 du CD-I (Video & System Controller) */
struct scc66470_s  {
    uint16_t csr_control;   /* écrit via 1FFFE0 */
    uint16_t bcr, dcr2;
    uint16_t csr;        /* Control/Status Register   (0x1FFFE0/E1) */
    uint16_t dcr;        /* Display Command Register  (0x1FFFE2)    */
    uint16_t vsr;        /* Video Start/Storage Register      (0x1FFFE8)    */
    uint16_t reg_c0;     /* registres divers          (0x1FFFC0)    */
    uint16_t reg_c2;
    uint16_t reg_c8;
    uint8_t vsc_status_toggle;
    /* État interne pour la synchro vidéo */
    uint64_t scanline_counter;  /* incrémenté par le tick vidéo */
};

void    scc66470_init(scc66470_t *v);
void    scc66470_tick(scc66470_t *v, int cpu_cycles);   /* avance la synchro */
uint8_t scc66470_read8 (scc66470_t *v, uint32_t addr);
void    scc66470_write8(scc66470_t *v, uint32_t addr, uint8_t val);
uint16_t scc66470_read16 (scc66470_t *v, uint32_t addr);
void     scc66470_write16(scc66470_t *v, uint32_t addr, uint16_t val);

/* ================================================================
   Register map — all Channel B registers are absolute addresses.
   They happen to form a contiguous block starting at 0x1FFFE0,
   but each is defined as its own explicit value to avoid any
   bitwise-OR surprises.

   Big-endian 68k convention: even address = high byte,
                              odd  address = low  byte.
   ================================================================ */
#define SCC_CSR   0x1FFFE0u          /* 0x1FFFE0 Control/Status Reg  */
#define SCC_DCR   0x1FFFE2u          /* 0x1FFFE2 Display Command Reg */
#define SCC_VSR   0x1FFFE4u          /* 0x1FFFE4 Video Start Reg      */
#define SCC_BCR   0x1FFFE6u          /* 0x1FFFE6 Border Color Reg    */
#define SCC_DCR2  0x1FFFE8u          /* 0x1FFFE8 Display Command Reg 2*/
#define SCC_DCP   0x1FFFEAu          /* 0x1FFFEA Display Command Ptr  */
#define SCC_SWM   0x1FFFECu          /* 0x1FFFEC Sync Width Modify   */
#define SCC_A     0x1FFFF0u          /* 0x1FFFF0 Source Pointer A    */
#define SCC_B     0x1FFFF2u          /* 0x1FFFF2 Source Pointer B    */
#define SCC_PCR   0x1FFFF4u          /* 0x1FFFF4 Pixel Control Reg   */

/* Low I/O registers — absolute, NOT derived from SCC_BASE */
#define SCC_MASK  0x1FFFF6u
#define SCC_SHIFT 0x1FFFF8u
#define SCC_INDEX 0x1FFFFBu
#define SCC_FC    0x1FFFFCu
#define SCC_BC    0x1FFFFDu
#define SCC_TC    0x1FFFFEu

/* Channel A mirror block (base 0x1FFFC0, hardcoded in write16) */
#define SCC_A_CSR 0x1FFFC0u
#define SCC_A_DCR 0x1FFFC2u
#define SCC_A_DCR2 0x1FFFC8u

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#ifdef _WIN32
  #include <io.h>
  #include <fcntl.h>
#endif
#include "core/m68k.h"
#include "core/bus.h"
#include "core/rom_loader.h"
#include "core/slave.h"
#include "core/scc66470.h"

/* g_video is now defined in bus.c (non-static) and declared via extern in bus.h */

static slave_t g_slave;

int main(void) {
    printf("=== CD-I 205 Emulator ===\n");

#ifdef _WIN32
    setvbuf(stdin, NULL, _IONBF, 0);
#endif

    bus_t *bus = bus_create();
    if (!bus) {
        fprintf(stderr,"Failed to create bus\n");
        return 1;
    }

    if (bus_load_ihex(bus, "./ROM/CDI205-00_PS-7211_REL.2.1.hex") != 0) {
        fprintf(stderr,"Failed to load ROM\n");
        bus_destroy(bus); return 1;
    }
    printf("ROM loaded successfully\n");

    m68k_t cpu;
    m68k_init(&cpu);
    m68k_set_bus(&cpu, bus);

    slave_backend_t *be = NULL;

    /* essa LLE si une ROM HC05 est fournie */
    /* be = slave_lle_create(hc05_rom, hc05_len); */

    /* sinon (cas actuel) : HLE */
    if (!be) {
        be = slave_hle_create();
    }
    slave_attach(&g_slave, be);
    slave_reset(&g_slave);

    m68k_reset(&cpu);

    printf("PC=0x%08X SR=0x%04X A7=0x%08X\n",
           cpu.pc, cpu.sr, cpu.a[7]);

    uart_feed('1');

    /* Controle du tracage instruction-par-instruction
     * - trace_enable : 1 = actif, 0 = desactive
     */
    int  trace_enable = 1;
    long trace_max = 10000;
    bool enter_service_mode = true;
    {
        const char *envm = getenv("EMU_TRACE_MAX");
        if (envm) trace_max = atol(envm);
    }

    printf("\nStarting emulation loop...\n");

    long traced = 0;

    if (enter_service_mode) {
        /* nothing yet */
    }

    for (long i = 0; i < 9200; i++) {
        uart_poll_host_input();

        if (trace_enable && traced < trace_max) {
            if (traced > 7430) {
                uint32_t pc_before = cpu.pc;
                fprintf(stderr, "[%06ld] PC=%08X  op=%04X  A7=%08X  SR=%04X\n",
                        traced,
                        pc_before,
                        bus_read16(bus, pc_before),
                        cpu.a[7], cpu.sr);
            }

            if (enter_service_mode && traced == 20)
                uart_inject_rx(bus, 0x05);
            traced++;
        }

        if (cpu.pc == 0x00180E40) {
            /* nothing yet */
        }

        /* UNE SEULE execution par tour */
        int cycles = m68k_step(&cpu);

        scc66470_tick(&g_video, cycles);

        if (cpu.stopped || cpu.halted) {
            printf("CPU stopped/halted at PC=0x%08X\n", cpu.pc);
            break;
        }

        if (trace_max > 0 && traced >= trace_max) {
            fflush(stdout);
            return 0;
        }
    }

    bus_destroy(bus);
    printf("\nEmulation stopped\n");
    return 0;
}

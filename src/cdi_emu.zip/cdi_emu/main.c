#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "core/m68k.h"
#include "core/bus.h"
#include "core/rom_loader.h"

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    bus_t bus = {0};
    m68k_t cpu;

    /* Charger la ROM binaire (swap EEPROM actif = 1) */
    bus.rom = load_rom_bin("./ROM/CDI205-00_PS-7211_REL.2.1.bin", &bus.rom_size, 1);
    if (!bus.rom) {
        fprintf(stderr, "Erreur: impossible de charger la ROM .bin\n");
        return 1;
    }

    /* RAM CD-i 205 : 1 Mo */
    bus.ram_size = 1024 * 1024;
    bus.ram = calloc(1, bus.ram_size);
    if (!bus.ram) {
        fprintf(stderr, "Erreur: impossible d'allouer la RAM\n");
        return 1;
    }

    /* Overlay ROM : le 68000 voit la ROM en 0x000000 au reset */
    bus.rom_overlay = true;

    /* Init CPU */
    m68k_init(&cpu);
    m68k_set_bus(&cpu, &bus);
    m68k_reset(&cpu);

    printf("=== Philips CD-i 205 Emulator ===\n");
    printf("ROM size : %zu bytes\n", bus.rom_size);
    printf("Boot SSP : 0x%08X\n", cpu.a[7]);
    printf("Boot PC  : 0x%06X\n", cpu.pc);

    /* Trace des premiers pas */
    for (int i = 0; i < 30; i++) {
        uint32_t pc = cpu.pc;
        int cycles = m68k_step(&cpu);
        if (cpu.halted) {
            printf("HALT at PC=0x%06X\n", pc);
            break;
        }
        if (i < 8) {
            printf("Step %02d | PC=0x%06X | cycles=%d\n", i, pc, cycles);
        }
    }

    free(bus.rom);
    free(bus.ram);
    return 0;
}

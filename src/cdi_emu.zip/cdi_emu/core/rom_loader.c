#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "rom_loader.h"

static int hex_digit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

uint8_t *load_rom_hex(const char *path, size_t *size) {
    FILE *f = fopen(path, "r");
    if (!f) { perror(path); return NULL; }

    uint8_t *rom = calloc(1, 0x80000);
    if (!rom) { fclose(f); return NULL; }

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] != ':') continue;
        int len = (hex_digit(line[1]) << 4) | hex_digit(line[2]);
        int addr = (hex_digit(line[3]) << 12) | (hex_digit(line[4]) << 8)
                 | (hex_digit(line[5]) << 4)  | hex_digit(line[6]);
        int type = (hex_digit(line[7]) << 4) | hex_digit(line[8]);
        if (type == 1) break;

        int idx = 9;
        for (int i = 0; i < len; i++) {
            int b = (hex_digit(line[idx]) << 4) | hex_digit(line[idx+1]);
            idx += 2;
            if ((addr + i) < 0x80000)
                rom[addr + i] = (uint8_t)b;
        }
    }
    fclose(f);
    *size = 0x80000;
    return rom;
}

uint8_t *load_rom_bin(const char *path, size_t *size, int byteswap_words) {
    FILE *f = fopen(path, "rb");
    if (!f) { perror(path); return NULL; }

    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    rewind(f);
    if (fsize <= 0) { fclose(f); return NULL; }

    uint8_t *buf = malloc(fsize);
    if (!buf) { fclose(f); return NULL; }

    if (fread(buf, 1, fsize, f) != (size_t)fsize) {
        free(buf); fclose(f); return NULL;
    }
    fclose(f);

    /* Si la ROM .bin est un dump d'EEPROM avec lignes D0-D7 inversées,
       on la "dé-swap" ici pour que le 68000 la lise en big-endian natif */
    if (byteswap_words) {
        for (long i = 0; i < fsize - 1; i += 2) {
            uint8_t tmp = buf[i];
            buf[i]      = buf[i+1];
            buf[i+1]    = tmp;
        }
    }

    *size = fsize;
    return buf;
}

uint8_t *load_rom(const char *path, size_t *size) {
    const char *dot = strrchr(path, '.');
    if (dot && strcasecmp(dot, ".hex") == 0) {
        return load_rom_hex(path, size);
    }
    /* Par défaut binaire avec swap EEPROM actif */
    return load_rom_bin(path, size, 1);
}

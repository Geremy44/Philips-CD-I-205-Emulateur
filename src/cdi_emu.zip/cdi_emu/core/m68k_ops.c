#include "m68k_ops.h"
#include "m68k_ea.h"
#include <stdio.h>

/* SR flag bit masks (also in m68k.h for visibility) */
#ifndef SR_N
#define SR_N  0x0008
#endif
#ifndef SR_Z
#define SR_Z  0x0004
#endif
#ifndef SR_V
#define SR_V  0x0002
#endif
#ifndef SR_C
#define SR_C  0x0001
#endif
#ifndef SR_X
#define SR_X  0x0010
#endif

/* ----- Flag helpers ----- */
static void flag_NZ_clearVC(uint16_t *sr, uint32_t r, int size)
{
    /* Clear N and Z first, then set based on result */
    if (size == 8) {
        *sr &= ~(SR_N | SR_Z | SR_V | SR_C);
        if ((uint8_t)r == 0) *sr |= SR_Z;
        if (r & 0x80) *sr |= SR_N;
    } else if (size == 16) {
        *sr &= ~(SR_N | SR_Z | SR_V | SR_C);
        if ((uint16_t)r == 0) *sr |= SR_Z;
        if (r & 0x8000) *sr |= SR_N;
    } else {
        *sr &= ~(SR_N | SR_Z | SR_V | SR_C);
        if (r == 0) *sr |= SR_Z;
        if (r & 0x80000000) *sr |= SR_N;
    }
}

/* ----- Effective address helpers ----- */
static uint32_t ea_calc(m68k_t *cpu, uint8_t mode, uint8_t reg, int size)
{
    (void)size;
    if (mode == 0) return 0x80000000 | reg;          /* Dn */
    if (mode == 1) return 0x90000000 | reg;          /* An */
    if (mode == 2) return cpu->a[reg];               /* (An) */
    if (mode == 3) return cpu->a[reg];               /* (An)+ */
    if (mode == 4) return cpu->a[reg];               /* -(An) */
    /* (d16,An) / (d8,An,Xi) / #imm / (An,Xi) / etc. — simplified */
    return 0;
}

static uint32_t ea_read(m68k_t *cpu, uint8_t mode, uint8_t reg, int size)
{
    uint32_t raw = ea_calc(cpu, mode, reg, size);
    if ((raw & 0xF0000000) == 0x80000000) {
        return cpu->d[raw & 7];
    }
    if ((raw & 0xF0000000) == 0x90000000) {
        return cpu->a[raw & 7];
    }
    if (size == 8)  return m68k_read8 (cpu, raw);
    if (size == 16) return m68k_read16(cpu, raw);
    return m68k_read32(cpu, raw);
}

static void ea_write(m68k_t *cpu, uint8_t mode, uint8_t reg, uint32_t val, int size)
{
    uint32_t raw = ea_calc(cpu, mode, reg, size);
    if ((raw & 0xF0000000) == 0x80000000) {
        cpu->d[raw & 7] = val;
        return;
    }
    if ((raw & 0xF0000000) == 0x90000000) {
        cpu->a[raw & 7] = val;
        return;
    }
    if (size == 8) {
        bus_write8 (cpu->bus, raw, (uint8_t)val);
    } else if (size == 16) {
        bus_write16(cpu->bus, raw, (uint16_t)val);
    } else {
        bus_write32(cpu->bus, raw, val);
    }
}

/* ----- Condition code checker ----- */
static int cc_true(uint16_t sr, int cc)
{
    int n = (sr >> 3) & 1;
    int z = (sr >> 2) & 1;
    int v = (sr >> 1) & 1;
    int c = (sr >> 0) & 1;
    switch (cc) {
        case  0: return 1;                          /* TR     */
        case  1: return 0;                          /* FA     */
        case  2: return !(c || z);                 /* HI     */
        case  3: return c || z;                     /* LS     */
        case  4: return !(c);                      /* CC/HS  */
        case  5: return c;                          /* CS/LO  */
        case  6: return !(n || z);                 /* NE     */
        case  7: return n || z;                     /* EQ     */
        case  8: return !(v);                      /* VC     */
        case  9: return v;                          /* VS     */
        case 10: return !(n);                      /* PL     */
        case 11: return n;                          /* MI     */
        case 12: return !(n || v) || (n || v || z); /* GE     */
        case 13: return (n && v) || !(n || v);     /* LT     */
        case 14: return !(n || v) || z;             /* GT     */
        case 15: return (n || v) && !z;             /* LE     */
    }
    return 0;
}

/* ----- Stack helpers (use a[7] = SP) ----- */
static void push16(m68k_t *cpu, uint16_t val)
{
    cpu->a[7] -= 2;
    bus_write16(cpu->bus, cpu->a[7], val);
}

static void push32(m68k_t *cpu, uint32_t val)
{
    cpu->a[7] -= 4;
    bus_write32(cpu->bus, cpu->a[7], val);
}

/* ----- Opcode handlers ----- */
static void op_nop(m68k_t *cpu)         { (void)cpu; }

void m68k_step_ops(m68k_t *cpu)
{
    uint16_t insn = m68k_read16(cpu, cpu->pc);
    cpu->pc += 2;

    uint8_t  nib0 = (uint8_t)(insn >> 12);
    uint8_t  nib1 = (uint8_t)((insn >> 6) & 0x3F);
    uint8_t  ea_mode = (uint8_t)((insn >> 3) & 0x07);
    uint8_t  ea_reg  = (uint8_t)(insn & 0x07);

    switch (nib0) {

    case 0x0: /* ORI, ANDI, EORI, CMPI, Bit ops, MOVE from SR */
        /* ORI to SR: advance past the immediate operand */
        if ((insn & 0xFFFC) == 0x007C) {
            uint16_t imm = m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            cpu->sr |= (imm & 0x8717);  /* only defined bits writable in user mode */
            return;
        }
        /* ORI to CCR */
        if ((insn & 0xFFFF) == 0x003C) {
            uint8_t imm = m68k_read8(cpu, cpu->pc);
            cpu->pc += 2;
            cpu->sr &= ~0x0015;
            cpu->sr |= (imm & 0x0015);
            return;
        }
        /* ANDI to SR */
        if ((insn & 0xFFFC) == 0x027C) {
            uint16_t imm = m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            cpu->sr &= (imm | ~0x8717);
            return;
        }
        /* EORI to SR */
        if ((insn & 0xFFFC) == 0x0A7C) {
            uint16_t imm = m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            cpu->sr ^= (imm & 0x8717);
            return;
        }
        /* NOT */
        if ((insn & 0xFFC0) == 0x4600) {
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, 8);
            val = ~val;
            ea_write(cpu, ea_mode, ea_reg, val, 8);
            flag_NZ_clearVC(&cpu->sr, val, 8);
            return;
        }
        /* TST */
        if ((insn & 0xF000) == 0x4A00) {
            int size = 8;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            flag_NZ_clearVC(&cpu->sr, val, size);
            return;
        }
        return;

    case 0x1: /* MOVE.B */
        {
            int size = 8;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            /* Dispatch destination: (An)+ etc. — simplified for MOVE.B */
            ea_write(cpu, ea_mode, ea_reg, val, size);
            flag_NZ_clearVC(&cpu->sr, val, size);
        }
        return;

    case 0x2: /* MOVEA.L / MOVE.L */
        {
            int size = 32;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            if (nib1 >= 0x08 && nib1 < 0x10) {
                /* MOVEA: store to An — NO flag change */
                cpu->a[ea_reg] = val;
            } else {
                /* MOVE.L: set flags, clear V and C */
                ea_write(cpu, ea_mode, ea_reg, val, size);
                flag_NZ_clearVC(&cpu->sr, val, size);
            }
        }
        return;

    case 0x3: /* MOVEA.W / MOVE.W */
        {
            int size = 16;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            if (nib1 >= 0x08 && nib1 < 0x10) {
                /* MOVEA.W: sign-extend to 32-bit, store to An — NO flag change */
                cpu->a[ea_reg] = (int16_t)val;
            } else {
                ea_write(cpu, ea_mode, ea_reg, val, size);
                flag_NZ_clearVC(&cpu->sr, val, size);
            }
        }
        return;

    case 0x4: /* LEA, PEA, CLR, MOVEM, NOP, RESET */
        /* LEA: sets An, NO flag change */
        if ((insn & 0xF1C0) == 0x41C0) {
            uint32_t addr = ea_read(cpu, ea_mode, ea_reg, 32);
            cpu->a[ea_reg] = addr;
            return;
        }
        /* PEA: NO flag change */
        if ((insn & 0xF1C0) == 0x4850) {
            uint32_t addr = ea_read(cpu, ea_mode, ea_reg, 32);
            cpu->a[7] -= 4;
            bus_write32(cpu->bus, cpu->a[7], addr);
            return;
        }
        /* CLR */
        if ((insn & 0xFFC0) == 0x4200) {
            int size = 8;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            ea_write(cpu, ea_mode, ea_reg, 0, size);
            cpu->sr &= ~(SR_N | SR_Z | SR_V | SR_C);
            cpu->sr |= SR_Z;
            return;
        }
        return;

    case 0x5: /* Bcc, BSR, BRA */
        {
            int cc = (int)(insn >> 8) & 0x0F;
            if ((insn & 0xFF00) == 0x6100) {
                /* BSR: push return address, always taken */
                int16_t disp = (int8_t)(insn & 0xFF);
                if (disp == 0) {
                    disp = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                }
                push32(cpu, cpu->pc);
                cpu->pc = (uint32_t)(cpu->pc + disp);
                return;
            }
            if ((insn & 0xFF00) == 0x6000) {
                /* BRA: unconditional relative jump */
                int16_t disp = (int8_t)(insn & 0xFF);
                if (disp == 0) {
                    disp = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                }
                cpu->pc = (uint32_t)(cpu->pc + disp);
                return;
            }
            /* Bcc — condition checked BEFORE displacement */
            if (cc_true(cpu->sr, cc)) {
                int16_t disp = (int8_t)(insn & 0xFF);
                if (disp == 0) {
                    disp = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                }
                cpu->pc = (uint32_t)(cpu->pc + disp);
            }
        }
        return;

    case 0x6: /* MOVQ */
        cpu->d[ea_reg] = insn & 0xFF;
        flag_NZ_clearVC(&cpu->sr, insn & 0xFF, 8);
        return;

    case 0x7: /* MOVEQ */
        cpu->d[ea_reg] = insn & 0xFF;
        flag_NZ_clearVC(&cpu->sr, insn & 0xFF, 8);
        return;

    case 0x8: /* OR, DIVU, Scc, DBcc, TRAPcc */
        /* OR */
        if ((insn & 0xF000) == 0x8000) {
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, 16);
            int size = 16;
            cpu->d[0] = cpu->d[0] | (val & 0xFFFF);
            flag_NZ_clearVC(&cpu->sr, cpu->d[0], size);
            return;
        }
        return;

    case 0x9: /* SUB, SUBA */
        {
            int size = 16;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            if (nib1 >= 0x08 && nib1 < 0x10) {
                /* SUBA: NO flag change */
                cpu->a[ea_reg] -= val;
            } else {
                /* SUB: set flags, clear V and C */
                uint32_t res = cpu->d[0] - val;
                cpu->d[0] = res;
                flag_NZ_clearVC(&cpu->sr, res, size);
            }
        }
        return;

    case 0xA: /* (unused in 68000 base ISA) */
        return;

    case 0xB: /* CMP, CMPA, CMPI, EOR */
        {
            int size = 16;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            if (nib1 >= 0x08 && nib1 < 0x10) {
                /* CMPA: NO flag change */
                cpu->a[ea_reg] -= val;
            } else {
                /* CMP: set flags */
                uint32_t res = cpu->d[0] - val;
                flag_NZ_clearVC(&cpu->sr, res, size);
            }
        }
        return;

    case 0xC: /* AND, MULU, MULS, EXG, ABCD */
        /* AND */
        if ((insn & 0xF000) == 0xC000) {
            int size = 8;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            uint32_t res = cpu->d[0] & val;
            cpu->d[0] = res;
            flag_NZ_clearVC(&cpu->sr, res, size);
            return;
        }
        return;

    case 0xD: /* ADD, ADDA */
        {
            int size = 16;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            uint32_t val = ea_read(cpu, ea_mode, ea_reg, size);
            if (nib1 >= 0x08 && nib1 < 0x10) {
                /* ADDA: NO flag change */
                cpu->a[ea_reg] += val;
            } else {
                /* ADD: set flags, clear V and C */
                uint32_t res = cpu->d[0] + val;
                cpu->d[0] = res;
                flag_NZ_clearVC(&cpu->sr, res, size);
            }
        }
        return;

    case 0xE: /* ROL, ROR, ASR, ASL, LSR, LSL, shift/register */
        {
            int cc = (int)(insn >> 9) & 7;
            int size = 8;
            if ((insn & 0x00C0) == 0x00C0) size = 32;
            else if ((insn & 0x00C0) == 0x0080) size = 16;
            int count = (int)(insn >> 6) & 7;
            uint32_t res = cpu->d[0];
            if ((nib1 & 0x20) == 0 && cc == 0) {
                /* Register shift: count from register or immediate 8 */
                count = (insn >> 9) & 7;
                if (count == 0) count = 8;
            }
            /* ROR by count — simplified */
            res = (cpu->d[0] >> count) | (cpu->d[0] << (32 - count));
            cpu->d[0] = res;
            flag_NZ_clearVC(&cpu->sr, res, size);
        }
        return;

    case 0xF: /* (co-processor / F-line, stub for now) */
        return;

    default:
        return;
    }
}
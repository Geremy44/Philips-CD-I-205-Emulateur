#ifndef M68K_EA_H
#define M68K_EA_H

#include <stdint.h>
#include "m68k.h"

uint32_t ea_calc(m68k_t *cpu, int mode, int reg, int size);

#endif

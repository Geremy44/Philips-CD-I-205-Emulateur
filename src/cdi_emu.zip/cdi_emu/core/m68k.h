#ifndef M68K_H
#define M68K_H

#include <stdint.h>
#include <stdbool.h>
#include "bus.h"

typedef struct m68k {
    uint32_t d[8];
    uint32_t a[8];      /* a[7] is the stack pointer */
    uint32_t usp;
    uint32_t pc;
    uint16_t sr;
    bool halted;
    bus_t *bus;
} m68k_t;

void m68k_init(m68k_t *cpu);
void m68k_set_bus(m68k_t *cpu, bus_t *bus);
void m68k_reset(m68k_t *cpu);

uint8_t  m68k_read8 (m68k_t *cpu, uint32_t addr);
uint16_t m68k_read16(m68k_t *cpu, uint32_t addr);
uint32_t m68k_read32(m68k_t *cpu, uint32_t addr);

int m68k_step(m68k_t *cpu);

#endif
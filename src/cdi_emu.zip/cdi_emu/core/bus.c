#include "bus.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

uint8_t bus_read8(bus_t *bus, uint32_t addr) {
    /* Overlay ROM au reset : 0x000000-0x0003FF mirror la ROM */
    if (bus->rom_overlay && addr < 0x000400) {
        if (addr < bus->rom_size) return bus->rom[addr];
        return 0xFF;
    }

    /* RAM */
    if (addr < bus->ram_size) {
        return bus->ram[addr];
    }

    /* ROM lineaire a 0x180000+ */
    if (addr >= 0x180000 && addr < (0x180000 + bus->rom_size)) {
        return bus->rom[addr - 0x180000];
    }

    return 0xFF;
}

uint16_t bus_read16(bus_t *bus, uint32_t addr) {
    uint8_t hi = bus_read8(bus, addr);
    uint8_t lo = bus_read8(bus, addr + 1);
    return ((uint16_t)hi << 8) | lo;
}

void bus_write8(bus_t *bus, uint32_t addr, uint8_t val) {
    if (addr < bus->ram_size) {
        bus->ram[addr] = val;
        /* Desactivation de l'overlay : toute ecriture dans la zone basse */
        if (bus->rom_overlay && addr < 0x000400) {
            bus->rom_overlay = false;
        }
    }
}

void bus_write16(bus_t *bus, uint32_t addr, uint16_t val) {
    bus_write8(bus, addr,     (val >> 8) & 0xFF);
    bus_write8(bus, addr + 1,  val       & 0xFF);
}

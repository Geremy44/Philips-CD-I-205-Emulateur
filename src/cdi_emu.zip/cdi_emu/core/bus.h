#ifndef BUS_H
#define BUS_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

typedef struct bus {
    uint8_t  *ram;
    size_t   ram_size;
    uint8_t  *rom;
    size_t   rom_size;
    bool     rom_overlay;
} bus_t;

uint8_t  bus_read8 (bus_t *bus, uint32_t addr);
uint16_t bus_read16(bus_t *bus, uint32_t addr);
void     bus_write8 (bus_t *bus, uint32_t addr, uint8_t  val);
void     bus_write16(bus_t *bus, uint32_t addr, uint16_t val);

#endif

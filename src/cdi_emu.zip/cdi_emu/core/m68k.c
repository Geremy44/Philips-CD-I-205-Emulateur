#include "m68k.h"
#include <string.h>
#include <stdio.h>

void m68k_init(m68k_t *cpu) {
    memset(cpu, 0, sizeof(*cpu));
}

void m68k_set_bus(m68k_t *cpu, bus_t *bus) {
    cpu->bus = bus;
}

void m68k_reset(m68k_t *cpu) {
    cpu->sr = 0x2700;
    cpu->usp = 0;
    cpu->halted = false;

    for (int i = 0; i < 8; i++) cpu->d[i] = 0;
    for (int i = 0; i < 8; i++) cpu->a[i] = 0;

    cpu->a[7] = m68k_read32(cpu, 0x000000);  /* SSP via a7 */
    cpu->pc  = m68k_read32(cpu, 0x000004);
}

uint8_t m68k_read8(m68k_t *cpu, uint32_t addr) {
    return bus_read8(cpu->bus, addr);
}

uint16_t m68k_read16(m68k_t *cpu, uint32_t addr) {
    return bus_read16(cpu->bus, addr);
}

uint32_t m68k_read32(m68k_t *cpu, uint32_t addr) {
    uint32_t hi = bus_read16(cpu->bus, addr);
    uint32_t lo = bus_read16(cpu->bus, addr + 2);
    return (hi << 16) | lo;
}
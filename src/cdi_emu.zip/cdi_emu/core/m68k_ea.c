#include "m68k_ea.h"

uint32_t ea_calc(m68k_t *cpu, int mode, int reg, int size)
{
    switch (mode) {
        case 0: /* Dn */
            return 0x80000000 | reg;

        case 1: /* An */
            return 0x90000000 | reg;

        case 2: /* (An) */
            return cpu->a[reg];

        case 3: /* (An)+ */
        {
            uint32_t addr = cpu->a[reg];
            int inc = (size == 8) ? 1 : (size == 16) ? 2 : 4;
            if (reg == 7 && size == 8) inc = 2; /* alignement mot pour la pile */
            cpu->a[reg] += inc;
            return addr;
        }

        case 4: /* -(An) */
        {
            int inc = (size == 8) ? 1 : (size == 16) ? 2 : 4;
            if (reg == 7 && size == 8) inc = 2;
            cpu->a[reg] -= inc;
            return cpu->a[reg];
        }

        case 5: /* d16(An) */
        {
            int16_t disp = (int16_t)m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            return cpu->a[reg] + disp;
        }

        case 6: /* d8(An, Xn) */
        {
            uint16_t ext = m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            int8_t d8 = (int8_t)(ext & 0xFF);
            int xn = (ext >> 12) & 0xF;
            uint32_t xv = (xn & 8) ? cpu->a[xn & 7] : cpu->d[xn & 7];
            if (!(ext & 0x0800)) xv = (uint32_t)(int16_t)xv; /* registre index .W */
            /* sinon .L, rien à faire */
            return cpu->a[reg] + d8 + xv;
        }

        case 7: /* modes spéciaux */
            switch (reg) {
                case 0: /* abs.W */
                {
                    uint32_t addr = (uint32_t)(int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    return addr;
                }
                case 1: /* abs.L */
                {
                    uint32_t addr = m68k_read32(cpu, cpu->pc);
                    cpu->pc += 4;
                    return addr;
                }
                case 2: /* d16(PC) */
                {
                    int16_t disp = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    return cpu->pc + disp;
                }
                case 3: /* d8(PC, Xn) */
                {
                    uint16_t ext = m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    int8_t d8 = (int8_t)(ext & 0xFF);
                    int xn = (ext >> 12) & 0xF;
                    uint32_t xv = (xn & 8) ? cpu->a[xn & 7] : cpu->d[xn & 7];
                    if (!(ext & 0x0800)) xv = (uint32_t)(int16_t)xv;
                    return cpu->pc + d8 + xv;
                }
                /* case 4 (#imm) n'est PAS ici : il est géré directement par ea_read */
            }
    }
    return 0;
}

/* m68k_ea.c */
#include "m68k_ea.h"
#include <stdio.h>


uint32_t ea_read(m68k_t *cpu, uint8_t mode, uint8_t reg, int size)
{
    uint32_t raw = ea_calc(cpu, mode, reg, size);
    if ((raw & 0xF0000000u) == 0xF0000000u) return cpu->d[raw & 7];
    if ((raw & 0xF0000000u) == 0xE0000000u) return cpu->a[raw & 7];
    if (size == 8)  return m68k_read8 (cpu, raw);
    if (size == 16) return m68k_read16(cpu, raw);
    return m68k_read32(cpu, raw);
}


void ea_write(m68k_t *cpu, uint8_t mode, uint8_t reg, int size, uint32_t val)
{
    uint32_t raw = ea_calc(cpu, mode, reg, size);
    if ((raw & 0xF0000000u) == 0xF0000000u) { cpu->d[raw & 7] = val; return; }
    if ((raw & 0xF0000000u) == 0xE0000000u) { cpu->a[raw & 7] = val; return; }
    if (size == 8)       bus_write8 (cpu->bus, raw, (uint8_t)val);
    else if (size == 16) bus_write16(cpu->bus, raw, (uint16_t)val);
    else                 bus_write32(cpu->bus, raw, val);
}



uint32_t ea_calc(m68k_t *cpu, uint8_t mode, uint8_t reg, int size)
{
    switch (mode) {
        case 0: /* Dn */
            return 0xF0000000u | reg;

        case 1: /* An */
            return 0xE0000000u | reg;

        case 2: /* (An) */
            return cpu->a[reg];

        case 3: /* (An)+ */
        {
            uint32_t addr = cpu->a[reg];
            int inc = (size == 8) ? 1 : (size == 16) ? 2 : 4;
            if (reg == 7 && size == 8) inc = 2; /* alignement mot pour la pile */
            cpu->a[reg] += inc;
            return addr;
        }

        case 4: /* -(An) */
        {
            int inc = (size == 8) ? 1 : (size == 16) ? 2 : 4;
            if (reg == 7 && size == 8) inc = 2;
            cpu->a[reg] -= inc;
            return cpu->a[reg];
        }

        case 5: /* d16(An) */
        {
            int16_t disp = (int16_t)m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            return cpu->a[reg] + disp;
        }

        case 6: /* d8(An, Xn) */
        {
            uint16_t ext = m68k_read16(cpu, cpu->pc);
            cpu->pc += 2;
            int8_t d8 = (int8_t)(ext & 0xFF);
            int xn = (ext >> 12) & 0xF;
            uint32_t xv = (xn & 8) ? cpu->a[xn & 7] : cpu->d[xn & 7];
            if (!(ext & 0x0800)) xv = (uint32_t)(int16_t)xv; /* registre index .W */
            return cpu->a[reg] + d8 + xv;
        }

        case 7:
            switch (reg) {
                case 0: { /* abs.W */
                    int16_t a = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    return (uint32_t)a;
                }
                case 1: { /* abs.L */
                    uint32_t a = m68k_read32(cpu, cpu->pc);
                    cpu->pc += 4;
                    return a;
                }
                case 2: { /* d16(PC) */
                    uint32_t base = cpu->pc;                 /* base = PC du mot d'extension */
                    int16_t d16 = (int16_t)m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    return base + (uint32_t)(int32_t)d16;
                }
                case 3: { /* d8(PC, Xn) */
                    uint32_t base = cpu->pc;
                    uint16_t ext = m68k_read16(cpu, cpu->pc);
                    cpu->pc += 2;
                    int8_t d8 = (int8_t)(ext & 0xFF);
                    int xn = (ext >> 12) & 0xF;
                    uint32_t xv = (xn & 8) ? cpu->a[xn & 7] : cpu->d[xn & 7];
                    if (!(ext & 0x0800)) xv = (uint32_t)(int16_t)xv; /* index .W */
                    return base + (uint32_t)(int32_t)d8 + xv;

                }

                case 4: { /* immédiat */
                    uint32_t a = cpu->pc;
                    cpu->pc += (size == 32) ? 4 : 2;
                    // printf("[IMM] pc=%06X  word=%04X  read8(a)=%02X read8(a+1)=%02X size=%d\n",
                    //     a, m68k_read16(cpu, a),
                    //     m68k_read8(cpu, a), m68k_read8(cpu, a+1), size);
                    return (size == 8) ? a + 1 : a;   // ← .b : octet bas du mot
                }

                default: {
                    fprintf(stderr,
                        "[ea_calc] mode7/reg invalide reg=%d PC=0x%08X "
                        "(opcode mal décodé en amont ?)\n",
                        reg, cpu->pc);
                    return 0;
                }
                
            }
            break;

        
        default:
            return 0;
    }
    /* mode/reg non géré → on le signale au lieu de retourner du garbage */
    fprintf(stderr,
            "[ea_calc] mode/reg non géré: mode=%u reg=%u (PC=0x%08X)\n",
            mode, reg, cpu->pc);
    cpu->stopped = 1;
    return 0;
}
